#include <iostream>
#include <limits>
#include <string>
#include <map>
#include <sstream>
#include <fstream>  // Include for file operations

// Function to safely input double values
double getDoubleInput(const std::string& prompt) {
    std::string input;
    double value;
    bool valid = false;

    while (!valid) {
        std::cout << prompt;
        getline(std::cin, input);
        std::stringstream ss(input);

        if (ss >> value) {
            char leftover;
            if (ss >> leftover) {
                std::cout << "Invalid input. Please enter a number only.\n";
            }
            else {
                valid = true;
            }
        }
        else {
            std::cout << "Invalid input. Please enter a number only.\n";
        }
    }
    return value;
}

void saveEarnings(const std::map<std::string, double>& earnings) {
    std::ofstream file("earnings.txt");
    for (const auto& week : earnings) {
        file << week.first << " " << week.second << "\n";
    }
    file.close();
}

void loadEarnings(std::map<std::string, double>& earnings) {
    std::ifstream file("earnings.txt");
    std::string dateLabel;
    double weeklyTotal;

    while (file >> dateLabel >> weeklyTotal) {
        earnings[dateLabel] = weeklyTotal;
    }
    file.close();
}

int main() {
    std::map<std::string, double> earnings;
    loadEarnings(earnings);

    while (true) {
        int choice;
        std::cout << "1. Enter Weekly Data\n";
        std::cout << "2. View Past Earnings\n";
        std::cout << "3. SAVE & Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (choice == 1) {
            std::string dateLabel;
            std::cout << "Enter the week label (e.g., 'Week of July 20'): ";
            getline(std::cin, dateLabel);

            double hourlyRate = getDoubleInput("Enter your hourly rate: $");
            double mileRate = getDoubleInput("Enter how many cents per mile you earn: ");
            double weeklyTotal = 0;

            std::string daysOfWeek[] = { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
            for (const std::string& day : daysOfWeek) {
                double hours = getDoubleInput("Enter hours worked on " + day + ": ");
                double miles = getDoubleInput("Enter miles driven on " + day + ": ");
                double dayPay = hours * hourlyRate + miles * (mileRate / 100);
                weeklyTotal += dayPay;
                std::cout << "Daily earnings on " << day << ": $" << dayPay << "\n";
            }

            earnings[dateLabel] = weeklyTotal;
            std::cout << "Total earnings for " << dateLabel << ": $" << weeklyTotal << "\n";
        }
        else if (choice == 2) {
            if (earnings.empty()) {
                std::cout << "No data available.\n";
            }
            else {
                for (const auto& week : earnings) {
                    std::cout << week.first << ": $" << week.second << "\n";
                }
            }
        }
        else if (choice == 3) {
            saveEarnings(earnings);
            break;
        }
        else {
            std::cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}

